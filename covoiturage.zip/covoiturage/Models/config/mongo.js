// L'url et le port de la base de données
let url = "mongodb://localhost:27017/model";
let MongoClient = require('.mongodb').MongoClient


module.exports = url
module.exports = MongoClient